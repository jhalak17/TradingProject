from django.contrib import admin

from .models import FormModel

# Register your models here.
admin.site.register(FormModel)
